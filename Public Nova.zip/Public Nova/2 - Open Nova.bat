@echo off
start "" "%~dp0nova.html"
