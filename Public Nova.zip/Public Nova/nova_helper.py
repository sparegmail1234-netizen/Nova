#!/usr/bin/env python3
"""
NOVA HELPER - lets Nova open apps and games on THIS computer.

Safety design:
  * Listens on 127.0.0.1 only (not reachable from other devices).
  * Every request needs the secret token in nova_token.txt.
  * Can ONLY open things listed in nova_apps.json (or http/https links).
    It never runs arbitrary commands sent by the webpage.

Run:  python3 nova_helper.py      (Windows: python nova_helper.py)
Needs Python 3.8+. No extra packages.
"""
import getpass
import hashlib
import hmac
import json
import os
import platform
import re
import secrets
import subprocess
import sys
import time
from datetime import datetime
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

HERE = os.path.dirname(os.path.abspath(__file__))
TOKEN_FILE = os.path.join(HERE, "nova_token.txt")
APPS_FILE = os.path.join(HERE, "nova_apps.json")
POWER_FILE = os.path.join(HERE, "nova_power.json")
LOG_FILE = os.path.join(HERE, "nova_power.log")
POWER = "--power" in sys.argv   # power mode: run any command, but only with your password
FAILS = 0
LOCKED_UNTIL = 0.0
HOST, PORT = "127.0.0.1", 8765
SYSTEM = platform.system()  # Windows / Darwin / Linux

DEFAULT_APPS = {
    "Windows": {
        "notepad": {"kind": "cmd", "args": ["notepad.exe"]},
        "calculator": {"kind": "cmd", "args": ["calc.exe"]},
        "paint": {"kind": "cmd", "args": ["mspaint.exe"]},
        "file explorer": {"kind": "cmd", "args": ["explorer.exe"]},
        "task manager": {"kind": "cmd", "args": ["taskmgr.exe"]},
        "chrome": {"kind": "cmd", "args": ["cmd", "/c", "start", "", "chrome"]},
        "edge": {"kind": "cmd", "args": ["cmd", "/c", "start", "", "msedge"]},
        "settings": {"kind": "uri", "value": "ms-settings:"},
        "steam": {"kind": "uri", "value": "steam://open/main"},
        "discord": {"kind": "uri", "value": "discord://"},
        "spotify": {"kind": "uri", "value": "spotify:"},
        "_example game": {"kind": "cmd", "args": ["C:\\Path\\To\\Your\\Game.exe"]},
    },
    "Darwin": {
        "calculator": {"kind": "cmd", "args": ["open", "-a", "Calculator"]},
        "safari": {"kind": "cmd", "args": ["open", "-a", "Safari"]},
        "chrome": {"kind": "cmd", "args": ["open", "-a", "Google Chrome"]},
        "notes": {"kind": "cmd", "args": ["open", "-a", "Notes"]},
        "settings": {"kind": "cmd", "args": ["open", "-a", "System Settings"]},
        "spotify": {"kind": "cmd", "args": ["open", "-a", "Spotify"]},
        "discord": {"kind": "cmd", "args": ["open", "-a", "Discord"]},
        "steam": {"kind": "cmd", "args": ["open", "-a", "Steam"]},
    },
    "Linux": {
        "calculator": {"kind": "cmd", "args": ["gnome-calculator"]},
        "files": {"kind": "cmd", "args": ["xdg-open", os.path.expanduser("~")]},
        "chrome": {"kind": "cmd", "args": ["google-chrome"]},
        "firefox": {"kind": "cmd", "args": ["firefox"]},
        "steam": {"kind": "uri", "value": "steam://open/main"},
        "discord": {"kind": "cmd", "args": ["discord"]},
        "spotify": {"kind": "cmd", "args": ["spotify"]},
    },
}


def load_token():
    if os.path.exists(TOKEN_FILE):
        with open(TOKEN_FILE, "r", encoding="utf-8") as f:
            token = f.read().strip()
            if token:
                return token
    token = secrets.token_urlsafe(24)
    with open(TOKEN_FILE, "w", encoding="utf-8") as f:
        f.write(token)
    try:
        os.chmod(TOKEN_FILE, 0o600)
    except OSError:
        pass
    return token


def load_file_apps():
    if not os.path.exists(APPS_FILE):
        with open(APPS_FILE, "w", encoding="utf-8") as f:
            json.dump(DEFAULT_APPS.get(SYSTEM, {}), f, indent=2)
    with open(APPS_FILE, "r", encoding="utf-8") as f:
        raw = json.load(f)
    return {k.lower().strip(): v for k, v in raw.items() if not k.startswith("_")}


# Shortcuts with these words in the name are never auto-added (so Nova can't
# be asked to shut the PC down, uninstall things, etc. through a shortcut).
BLOCKED_WORDS = ("uninstall", "shutdown", "shut down", "restart", "reboot", "sleep",
                 "hibernate", "log off", "logoff", "sign out", "format", "delete")


def _scan_dirs():
    home = os.path.expanduser("~")
    if SYSTEM == "Windows":
        appdata = os.environ.get("APPDATA", "")
        progdata = os.environ.get("PROGRAMDATA", "")
        public = os.environ.get("PUBLIC", "")
        dirs = [os.path.join(home, "Desktop"), os.path.join(public, "Desktop") if public else "",
                os.path.join(appdata, "Microsoft", "Windows", "Start Menu", "Programs") if appdata else "",
                os.path.join(progdata, "Microsoft", "Windows", "Start Menu", "Programs") if progdata else ""]
        # OneDrive-redirected Desktop
        for var in ("OneDrive", "OneDriveConsumer"):
            od = os.environ.get(var)
            if od:
                dirs.append(os.path.join(od, "Desktop"))
        return [d for d in dirs if d], {".lnk", ".url"}
    if SYSTEM == "Darwin":
        return ["/Applications", os.path.join(home, "Applications")], {".app"}
    return [os.path.join(home, "Desktop"), os.path.expanduser("~/.local/share/applications")], {".desktop"}


_scan_cache = {"t": 0.0, "apps": {}}


def scan_shortcuts():
    """Find shortcuts on the Desktop / Start Menu so every game and app is openable by name."""
    if time.time() - _scan_cache["t"] < 20:
        return _scan_cache["apps"]
    dirs, exts = _scan_dirs()
    found = {}
    for base in dirs:
        if not os.path.isdir(base):
            continue
        base_depth = base.rstrip(os.sep).count(os.sep)
        for root, subdirs, files in os.walk(base):
            if root.count(os.sep) - base_depth >= 3:
                subdirs[:] = []
            entries = list(files) + (list(subdirs) if SYSTEM == "Darwin" else [])
            for fn in entries:
                stem, ext = os.path.splitext(fn)
                if ext.lower() not in exts:
                    continue
                name = stem.lower().strip()
                if not name or any(w in name for w in BLOCKED_WORDS):
                    continue
                found.setdefault(name, {"kind": "path", "value": os.path.join(root, fn)})
    _scan_cache["t"], _scan_cache["apps"] = time.time(), found
    return found


def load_apps():
    """Scanned shortcuts first; entries in nova_apps.json override them."""
    merged = dict(scan_shortcuts())
    merged.update(load_file_apps())
    return merged


def _norm(s):
    return "".join(ch for ch in s.lower() if ch.isalnum())


def resolve(name, apps):
    """Match a spoken/typed name to an app. Returns (key, entry, options)."""
    if name in apps:
        return name, apps[name], []
    n = _norm(name)
    if not n:
        return None, None, []
    by_norm = {}
    for k in apps:
        by_norm.setdefault(_norm(k), k)
    if n in by_norm:
        k = by_norm[n]
        return k, apps[k], []
    cands = sorted(k for k in apps if n in _norm(k))
    if len(cands) == 1:
        return cands[0], apps[cands[0]], []
    return None, None, cands[:8]


def open_uri(value):
    if SYSTEM == "Windows":
        os.startfile(value)  # noqa: S606 - value comes from the user's own allowlist or an http(s) link
    elif SYSTEM == "Darwin":
        subprocess.Popen(["open", value])
    else:
        subprocess.Popen(["xdg-open", value])


def launch(entry):
    kind = entry.get("kind")
    if kind in ("uri", "path"):
        open_uri(entry["value"])
    elif kind == "cmd":
        args = entry["args"]
        if not isinstance(args, list) or not all(isinstance(a, str) for a in args):
            raise ValueError("args must be a list of strings")
        subprocess.Popen(args, shell=False)
    else:
        raise ValueError("unknown kind")


def _hash_pw(password, salt):
    return hashlib.pbkdf2_hmac("sha256", password.encode(), salt, 200_000)


def setup_power_password():
    """Ask for a password in the terminal the first time power mode is used."""
    if os.path.exists(POWER_FILE):
        return
    print("\nPOWER MODE setup: choose a password. Nova will ask for it every time")
    print("you want to run a command. It is stored only as a salted hash.")
    while True:
        a = getpass.getpass("New password (8+ characters): ")
        b = getpass.getpass("Repeat password: ")
        if len(a) < 8:
            print("Too short, try again.")
        elif a != b:
            print("They didn't match, try again.")
        else:
            break
    salt = secrets.token_bytes(16)
    with open(POWER_FILE, "w", encoding="utf-8") as f:
        json.dump({"salt": salt.hex(), "hash": _hash_pw(a, salt).hex()}, f)
    try:
        os.chmod(POWER_FILE, 0o600)
    except OSError:
        pass


def check_password(password):
    try:
        with open(POWER_FILE, "r", encoding="utf-8") as f:
            rec = json.load(f)
        want = bytes.fromhex(rec["hash"])
        got = _hash_pw(password, bytes.fromhex(rec["salt"]))
        return hmac.compare_digest(got, want)
    except Exception:
        return False


# Last-resort safety net. Even with the right password these are refused,
# because they can wreck the whole machine (wiping a drive, partitioning, etc.).
CATASTROPHIC = [
    r"\bformat\s+[a-z]:",
    r"\bdiskpart\b",
    r"\bmkfs(\.|\s)",
    r"\brm\s+(-\w+\s+)*(/|~|\*)(\s|$)",
    r"\b(rd|rmdir|del|erase|remove-item|rm)\b[^\n]*[\s'\"][a-z]:\\*['\"]?(\s|$|\*)",
    r"\\windows\\system32",
    r"\bbcdedit\b",
    r"\bdd\s+if=.*of=/dev/",
]


def is_catastrophic(command):
    c = command.lower()
    return any(re.search(pat, c) for pat in CATASTROPHIC)


def verify_with_lockout(password):
    """Check the power password with brute-force lockout. Returns (ok, http_status, message)."""
    global FAILS, LOCKED_UNTIL
    now = time.time()
    if now < LOCKED_UNTIL:
        return False, 429, "Too many wrong passwords. Locked for %d more seconds." % int(LOCKED_UNTIL - now)
    if check_password(password):
        FAILS = 0
        return True, 200, ""
    FAILS += 1
    if FAILS >= 5:
        LOCKED_UNTIL = now + 300
        FAILS = 0
    return False, 401, "wrong password"


def log(line):
    with open(LOG_FILE, "a", encoding="utf-8") as f:
        f.write("%s  %s\n" % (datetime.now().isoformat(timespec="seconds"), line))


# ---------------------------------------------------------------------------
# GAME CONTROL (Windows only): lets Nova press keys / click while a game you
# chose is in front. Safety rules, all enforced HERE, not in the webpage:
#   * needs the power password to start, and a session expires in <= 20 minutes
#   * input is only sent while the window you named is the one in the foreground
#   * only game-style keys (no Windows key, no Alt/Tab combos, no typing text)
#   * competitive online shooters / anti-cheat games are refused outright
# ---------------------------------------------------------------------------
GAME_SESSION = {"id": None, "title": "", "expires": 0.0, "mode": "game", "last_cursor": None}
DESK_MAX_MINUTES = 10
HOTKEYS = {"ctrl+a", "ctrl+c", "ctrl+v", "ctrl+x", "ctrl+z", "ctrl+y", "ctrl+s", "ctrl+f", "ctrl+l", "ctrl+t", "ctrl+w", "ctrl+r"}
# In desktop mode Nova will not touch windows that look sensitive (this includes the helper's own window).
DESK_SENSITIVE = [
    r"powershell", r"command prompt", r"cmd\.exe", r"windows terminal", r"\bterminal\b", r"regedit",
    r"registry editor", r"task manager", r"windows security", r"user account control", r"credential",
    r"password", r"sign ?in", r"log ?in", r"\bbank", r"paypal", r"wallet", r"1password", r"bitwarden",
    r"lastpass", r"keepass", r"nova_helper", r"nova helper",
]
GAME_MAX_MINUTES = 20
GAME_DENY = [
    r"\bcs ?2\b", r"\bcs:? ?go\b", r"counter.?strike", r"valorant", r"fortnite", r"apex legends",
    r"call of duty", r"warzone", r"overwatch", r"rainbow six", r"pubg", r"battlegrounds", r"battlefield",
    r"tarkov", r"\brust\b", r"league of legends", r"\bdota\b", r"rocket league", r"destiny 2",
    r"marvel rivals", r"the finals",
]
GAME_DENY_MESSAGE = ("I won't play that one, sir. Automating a competitive online game counts as cheating "
                     "and can get your account banned. Single-player and casual games are fine.")

# Scan codes (set 1) -> (scan, extended)
KEYS = {c: (s_, False) for c, s_ in zip("qwertyuiop", range(0x10, 0x1A))}
KEYS.update({c: (s_, False) for c, s_ in zip("asdfghjkl", range(0x1E, 0x27))})
KEYS.update({c: (s_, False) for c, s_ in zip("zxcvbnm", range(0x2C, 0x33))})
KEYS.update({str(d): (0x02 + (d - 1 if d else 9), False) for d in range(10)})
KEYS.update({"space": (0x39, False), "enter": (0x1C, False), "esc": (0x01, False), "tab": (0x0F, False),
             "shift": (0x2A, False), "ctrl": (0x1D, False),
             "up": (0x48, True), "down": (0x50, True), "left": (0x4B, True), "right": (0x4D, True)})


def game_title_denied(title):
    t = title.lower()
    return any(re.search(pat, t) for pat in GAME_DENY)


def desktop_sensitive(title):
    t = (title or "").lower()
    return any(re.search(pat, t) for pat in DESK_SENSITIVE)


def _xy(a):
    x, y = float(a.get("x")), float(a.get("y"))
    if not (0.0 <= x <= 1.0 and 0.0 <= y <= 1.0):
        raise ValueError("position must be between 0 and 1")
    button = str(a.get("button", "left")).lower()
    if button not in ("left", "right"):
        raise ValueError("bad mouse button")
    return x, y, button


def validate_actions(actions, mode="game"):
    """Return a cleaned list of actions, or raise ValueError. Nothing unusual gets through."""
    if not isinstance(actions, list) or not actions:
        raise ValueError("no actions")
    if len(actions) > 6:
        raise ValueError("too many actions at once")
    desktop = mode == "desktop"
    clean, total_ms, typed = [], 0, 0
    for a in actions:
        if not isinstance(a, dict):
            raise ValueError("bad action")
        kind = a.get("do")
        if kind == "key":
            key = str(a.get("key", "")).lower()
            if key not in KEYS:
                raise ValueError("key not allowed: %s" % key[:20])
            ms = int(max(30, min(3000, float(a.get("ms", 80)))))
            clean.append({"do": "key", "key": key, "ms": ms}); total_ms += ms
        elif kind == "click":
            x, y, button = _xy(a)
            clean.append({"do": "click", "x": x, "y": y, "button": button}); total_ms += 120
        elif kind in ("move", "double") and desktop:
            x, y, button = _xy(a)
            clean.append({"do": kind, "x": x, "y": y, "button": button}); total_ms += 200
        elif kind == "scroll" and desktop:
            dy = int(max(-15, min(15, float(a.get("dy", 0)))))
            if dy == 0:
                raise ValueError("scroll amount is zero")
            clean.append({"do": "scroll", "dy": dy}); total_ms += 100
        elif kind == "type" and desktop:
            text = "".join(ch for ch in str(a.get("text", "")) if ch == "\n" or ord(ch) >= 32)
            if not text or len(text) > 300:
                raise ValueError("text must be 1-300 characters")
            typed += len(text)
            if typed > 600:
                raise ValueError("too much text at once")
            clean.append({"do": "type", "text": text}); total_ms += len(text) * 30
        elif kind == "hotkey" and desktop:
            keys = str(a.get("keys", "")).lower().replace(" ", "")
            if keys not in HOTKEYS:
                raise ValueError("shortcut not allowed: %s" % keys[:20])
            clean.append({"do": "hotkey", "keys": keys}); total_ms += 150
        elif kind == "wait":
            ms = int(max(0, min(2000, float(a.get("ms", 500)))))
            clean.append({"do": "wait", "ms": ms}); total_ms += ms
        else:
            raise ValueError("unknown or not allowed action")
    if total_ms > (15000 if desktop else 8000):
        raise ValueError("actions take too long in total")
    return clean


if SYSTEM == "Windows":
    import ctypes
    from ctypes import wintypes
    _user32 = ctypes.windll.user32
    try:
        _user32.SetProcessDPIAware()
    except Exception:
        pass
    _ULONG_PTR = ctypes.c_size_t

    class _KEYBDINPUT(ctypes.Structure):
        _fields_ = [("wVk", wintypes.WORD), ("wScan", wintypes.WORD), ("dwFlags", wintypes.DWORD),
                    ("time", wintypes.DWORD), ("dwExtraInfo", _ULONG_PTR)]

    class _MOUSEINPUT(ctypes.Structure):
        _fields_ = [("dx", wintypes.LONG), ("dy", wintypes.LONG), ("mouseData", wintypes.DWORD),
                    ("dwFlags", wintypes.DWORD), ("time", wintypes.DWORD), ("dwExtraInfo", _ULONG_PTR)]

    class _HARDWAREINPUT(ctypes.Structure):
        _fields_ = [("uMsg", wintypes.DWORD), ("wParamL", wintypes.WORD), ("wParamH", wintypes.WORD)]

    class _INPUTUNION(ctypes.Union):
        _fields_ = [("ki", _KEYBDINPUT), ("mi", _MOUSEINPUT), ("hi", _HARDWAREINPUT)]

    class _INPUT(ctypes.Structure):
        _fields_ = [("type", wintypes.DWORD), ("u", _INPUTUNION)]

    def _send_key(scan, extended, up):
        flags = 0x0008 | (0x0002 if up else 0) | (0x0001 if extended else 0)   # SCANCODE | KEYUP | EXTENDED
        inp = _INPUT(type=1, u=_INPUTUNION(ki=_KEYBDINPUT(0, scan, flags, 0, 0)))
        _user32.SendInput(1, ctypes.byref(inp), ctypes.sizeof(_INPUT))

    def _foreground_title():
        hwnd = _user32.GetForegroundWindow()
        n = _user32.GetWindowTextLengthW(hwnd)
        buf = ctypes.create_unicode_buffer(n + 1)
        _user32.GetWindowTextW(hwnd, buf, n + 1)
        return buf.value

    def _key_tap(name, ms):
        scan, ext = KEYS[name]
        _send_key(scan, ext, False)
        time.sleep(ms / 1000.0)
        _send_key(scan, ext, True)

    def _click(fx, fy, button):
        rect = wintypes.RECT()
        _user32.GetWindowRect(_user32.GetForegroundWindow(), ctypes.byref(rect))
        x = int(rect.left + fx * (rect.right - rect.left))
        y = int(rect.top + fy * (rect.bottom - rect.top))
        _user32.SetCursorPos(x, y)
        down, up = (0x0002, 0x0004) if button == "left" else (0x0008, 0x0010)
        _user32.mouse_event(down, 0, 0, 0, 0)
        time.sleep(0.05)
        _user32.mouse_event(up, 0, 0, 0, 0)

    def _screen_size():
        return _user32.GetSystemMetrics(0), _user32.GetSystemMetrics(1)

    def _cursor_pos():
        pt = wintypes.POINT()
        _user32.GetCursorPos(ctypes.byref(pt))
        return pt.x, pt.y

    def _move_screen(fx, fy):
        w, h = _screen_size()
        _user32.SetCursorPos(int(fx * (w - 1)), int(fy * (h - 1)))

    def _click_screen(fx, fy, button, double):
        _move_screen(fx, fy)
        time.sleep(0.05)
        down, up = (0x0002, 0x0004) if button == "left" else (0x0008, 0x0010)
        for _ in range(2 if double else 1):
            _user32.mouse_event(down, 0, 0, 0, 0)
            time.sleep(0.05)
            _user32.mouse_event(up, 0, 0, 0, 0)
            time.sleep(0.08)

    def _scroll(dy):   # positive = scroll down
        _user32.mouse_event(0x0800, 0, 0, ctypes.c_ulong((-dy * 120) & 0xFFFFFFFF).value, 0)

    def _send_unicode(code, up):
        flags = 0x0004 | (0x0002 if up else 0)   # UNICODE | KEYUP
        inp = _INPUT(type=1, u=_INPUTUNION(ki=_KEYBDINPUT(0, code, flags, 0, 0)))
        _user32.SendInput(1, ctypes.byref(inp), ctypes.sizeof(_INPUT))

    def _type_text(text):
        for ch in text:
            if ch == "\n":
                _key_tap("enter", 30)
                continue
            raw = ch.encode("utf-16-le")
            for i in range(0, len(raw), 2):
                code = raw[i] | (raw[i + 1] << 8)
                _send_unicode(code, False)
                _send_unicode(code, True)
            time.sleep(0.02)

    def _hotkey(keys):
        mod, key = keys.split("+")
        scan = KEYS[mod][0]
        _send_key(scan, False, False)
        time.sleep(0.04)
        _key_tap(key, 60)
        _send_key(scan, False, True)
else:
    def _foreground_title():
        raise RuntimeError("Game control only works on Windows.")

    def _key_tap(name, ms):
        raise RuntimeError("Game control only works on Windows.")

    def _click(fx, fy, button):
        raise RuntimeError("Game control only works on Windows.")

    def _cursor_pos():
        raise RuntimeError("Game control only works on Windows.")

    def _move_screen(fx, fy):
        raise RuntimeError("Game control only works on Windows.")

    def _click_screen(fx, fy, button, double):
        raise RuntimeError("Game control only works on Windows.")

    def _scroll(dy):
        raise RuntimeError("Game control only works on Windows.")

    def _type_text(text):
        raise RuntimeError("Game control only works on Windows.")

    def _hotkey(keys):
        raise RuntimeError("Game control only works on Windows.")


TOKEN = load_token()


class Handler(BaseHTTPRequestHandler):
    server_version = "NovaHelper/1.0"

    def log_message(self, fmt, *args):
        sys.stderr.write("[nova-helper] " + (fmt % args) + "\n")

    def _cors(self):
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Headers", "Content-Type, X-Nova-Token")
        self.send_header("Access-Control-Allow-Methods", "GET, POST, OPTIONS")
        self.send_header("Access-Control-Allow-Private-Network", "true")

    def _send(self, code, payload):
        body = json.dumps(payload).encode()
        self.send_response(code)
        self._cors()
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def _host_ok(self):
        # Blocks DNS-rebinding tricks: only accept requests addressed to localhost.
        host = (self.headers.get("Host") or "").split(":")[0]
        return host in ("127.0.0.1", "localhost")

    def _authed(self):
        given = self.headers.get("X-Nova-Token") or ""
        return hmac.compare_digest(given.encode(), TOKEN.encode())

    def do_OPTIONS(self):
        self.send_response(204)
        self._cors()
        self.end_headers()

    def do_GET(self):
        if not self._host_ok():
            return self._send(403, {"error": "bad host"})
        if not self._authed():
            return self._send(401, {"error": "bad token"})
        if self.path == "/ping":
            return self._send(200, {"ok": True, "system": SYSTEM, "power": POWER})
        if self.path == "/apps":
            return self._send(200, {"apps": sorted(load_apps().keys())})
        self._send(404, {"error": "not found"})

    def _handle_run(self):
        global FAILS, LOCKED_UNTIL
        if not POWER:
            return self._send(403, {"error": "Power mode is off. Restart the helper with: python nova_helper.py --power"})
        now = time.time()
        if now < LOCKED_UNTIL:
            return self._send(429, {"error": "Too many wrong passwords. Locked for %d more seconds." % int(LOCKED_UNTIL - now)})
        try:
            length = int(self.headers.get("Content-Length") or 0)
            data = json.loads(self.rfile.read(min(length, 8192)) or b"{}")
            command = str(data.get("command", "")).strip()
            password = str(data.get("password", ""))
            visible = bool(data.get("visible"))
        except Exception:
            return self._send(400, {"error": "bad request"})
        if not command:
            return self._send(400, {"error": "no command"})
        if not check_password(password):
            FAILS += 1
            if FAILS >= 5:
                LOCKED_UNTIL = now + 300
                FAILS = 0
            log("DENIED (wrong password): " + command)
            return self._send(401, {"error": "wrong password"})
        FAILS = 0
        if is_catastrophic(command):
            log("BLOCKED (too dangerous): " + command)
            return self._send(403, {"error": "That command is on the helper's never-run list (it could wreck your computer), so I refused it even with the right password."})
        log("RUN%s: %s" % (" (visible window)" if visible and SYSTEM == "Windows" else "", command))
        if visible and SYSTEM == "Windows":
            # Slow jobs like installs run in their own window so you can watch progress.
            try:
                subprocess.Popen('start "Nova task" cmd /k ' + command, shell=True)
                return self._send(200, {"ok": True, "code": 0, "output": "Started in a new window on your computer. Watch that window for progress."})
            except Exception as exc:
                return self._send(500, {"error": str(exc)})
        try:
            r = subprocess.run(command, shell=True, capture_output=True, text=True, timeout=30)
            out = ((r.stdout or "") + (r.stderr or ""))[-4000:]
            return self._send(200, {"ok": r.returncode == 0, "code": r.returncode, "output": out})
        except subprocess.TimeoutExpired:
            return self._send(200, {"ok": False, "output": "Timed out after 30 seconds."})
        except Exception as exc:
            return self._send(500, {"error": str(exc)})

    def _handle_verify(self):
        if not POWER:
            return self._send(200, {"ok": True, "power": False})
        try:
            length = int(self.headers.get("Content-Length") or 0)
            data = json.loads(self.rfile.read(min(length, 1024)) or b"{}")
        except Exception:
            return self._send(400, {"error": "bad request"})
        ok, code, msg = verify_with_lockout(str(data.get("password", "")))
        if not ok:
            log("DENIED (wrong password) on verify")
            return self._send(code, {"error": msg})
        return self._send(200, {"ok": True, "power": True})

    def _read_json(self, limit=4096):
        length = int(self.headers.get("Content-Length") or 0)
        return json.loads(self.rfile.read(min(length, limit)) or b"{}")

    def _handle_game_start(self):
        if not POWER:
            return self._send(403, {"error": "Power mode is off. Start the helper with the power launcher."})
        if SYSTEM != "Windows":
            return self._send(501, {"error": "Game and mouse control only work on Windows."})
        try:
            data = self._read_json()
            mode = "desktop" if str(data.get("mode", "game")) == "desktop" else "game"
            title = str(data.get("title", "")).strip()
            cap = DESK_MAX_MINUTES if mode == "desktop" else GAME_MAX_MINUTES
            minutes = int(max(1, min(cap, float(data.get("minutes", 10)))))
        except Exception:
            return self._send(400, {"error": "bad request"})
        if mode == "game":
            if len(title) < 3:
                return self._send(400, {"error": "Tell me the game's window name, sir."})
            if game_title_denied(title):
                log("GAME DENIED (competitive/online): " + title)
                return self._send(403, {"error": GAME_DENY_MESSAGE})
        else:
            title = "(whole desktop)"
        ok, code, msg = verify_with_lockout(str(data.get("password", "")))
        if not ok:
            log("DENIED %s start (%s)" % (mode, msg))
            return self._send(code, {"error": msg})
        GAME_SESSION.update({"id": secrets.token_urlsafe(16), "title": title, "mode": mode,
                             "expires": time.time() + minutes * 60, "last_cursor": None})
        log("%s START: %s for %d min" % (mode.upper(), title, minutes))
        return self._send(200, {"ok": True, "session": GAME_SESSION["id"], "minutes": minutes, "mode": mode})

    def _do_action(self, a, mode):
        kind = a["do"]
        if kind == "key":
            _key_tap(a["key"], a["ms"])
        elif kind == "click":
            if mode == "game":
                _click(a["x"], a["y"], a["button"])
            else:
                _click_screen(a["x"], a["y"], a["button"], False)
                GAME_SESSION["last_cursor"] = _cursor_pos()
        elif kind == "double":
            _click_screen(a["x"], a["y"], a["button"], True)
            GAME_SESSION["last_cursor"] = _cursor_pos()
        elif kind == "move":
            _move_screen(a["x"], a["y"])
            GAME_SESSION["last_cursor"] = _cursor_pos()
        elif kind == "scroll":
            _scroll(a["dy"])
        elif kind == "type":
            _type_text(a["text"])
        elif kind == "hotkey":
            _hotkey(a["keys"])
        else:
            time.sleep(a["ms"] / 1000.0)

    def _handle_game_input(self):
        mode = GAME_SESSION.get("mode", "game")
        try:
            data = self._read_json(16384)
            sid = str(data.get("session", ""))
            actions = validate_actions(data.get("actions"), mode)
        except ValueError as exc:
            return self._send(400, {"error": str(exc)})
        except Exception:
            return self._send(400, {"error": "bad request"})
        if GAME_SESSION["id"] and time.time() > GAME_SESSION["expires"]:
            GAME_SESSION["id"] = None          # expired: end it for real
        if not GAME_SESSION["id"] or not hmac.compare_digest(sid.encode(), GAME_SESSION["id"].encode()):
            # A wrong id is just refused; it must never end somebody else's valid session.
            return self._send(410, {"error": "The session has ended."})
        want = GAME_SESSION["title"].lower()
        try:
            if mode == "desktop" and GAME_SESSION.get("last_cursor"):
                lx, ly = GAME_SESSION["last_cursor"]
                cx, cy = _cursor_pos()
                if abs(cx - lx) > 40 or abs(cy - ly) > 40:
                    GAME_SESSION["id"] = None
                    log("DESKTOP STOP: user moved the mouse")
                    return self._send(410, {"error": "You moved the mouse, so I've stopped, sir."})
            for a in actions:
                focused = _foreground_title()
                if mode == "game" and want not in focused.lower():
                    return self._send(409, {"error": "The game window isn't in front.", "focused": focused[:60]})
                if mode == "desktop" and desktop_sensitive(focused):
                    return self._send(423, {"error": "That window looks sensitive (%s), so I won't touch it." % focused[:40]})
                self._do_action(a, mode)
        except Exception as exc:
            return self._send(500, {"error": str(exc)})
        names = ", ".join(a["do"] + (":" + a["key"] if a["do"] == "key" else "") + ("(len=%d)" % len(a["text"]) if a["do"] == "type" else "") for a in actions)
        log("%s INPUT: %s" % (mode.upper(), names))
        return self._send(200, {"ok": True, "done": len(actions)})

    def _handle_game_stop(self):
        GAME_SESSION["id"] = None
        log("GAME STOP")
        return self._send(200, {"ok": True})

    def do_POST(self):
        if not self._host_ok():
            return self._send(403, {"error": "bad host"})
        if not self._authed():
            return self._send(401, {"error": "bad token"})
        if self.path == "/run":
            return self._handle_run()
        if self.path == "/verify":
            return self._handle_verify()
        if self.path == "/game/start":
            return self._handle_game_start()
        if self.path == "/game/input":
            return self._handle_game_input()
        if self.path == "/game/stop":
            return self._handle_game_stop()
        if self.path != "/open":
            return self._send(404, {"error": "not found"})
        try:
            length = int(self.headers.get("Content-Length") or 0)
            data = json.loads(self.rfile.read(min(length, 4096)) or b"{}")
            name = str(data.get("name", "")).lower().strip()
        except Exception:
            return self._send(400, {"error": "bad request"})
        if POWER:
            # In power mode, opening anything also needs the password.
            ok, code, msg = verify_with_lockout(str(data.get("password", "")))
            if not ok:
                log("DENIED open (%s): %s" % (msg, name))
                return self._send(code, {"error": msg})
            log("OPEN: " + name)
        try:
            if name.startswith(("http://", "https://")):
                open_uri(name)
                return self._send(200, {"ok": True, "opened": name})
            apps = load_apps()
            key, entry, options = resolve(name, apps)
            if entry is None:
                if len(options) > 1:
                    return self._send(409, {"error": "ambiguous", "options": options})
                return self._send(404, {"error": "unknown app", "hint": "Say 'list apps' to see what I can open."})
            launch(entry)
            return self._send(200, {"ok": True, "opened": key})
        except Exception as exc:  # app missing, bad config, etc.
            return self._send(500, {"error": str(exc)})


def main():
    load_file_apps()  # creates nova_apps.json on first run
    print("Found %d apps/games from your Desktop and Start Menu." % len(scan_shortcuts()))
    if POWER:
        setup_power_password()
    print("=" * 60)
    print("NOVA HELPER running on http://%s:%d" % (HOST, PORT))
    print("Your secret token (paste into Nova > Settings > Computer Helper):")
    print()
    print("    " + TOKEN)
    print()
    print("It auto-detects Desktop + Start Menu shortcuts. Extra/override entries: " + APPS_FILE)
    print("Edit that file to add your games. Press Ctrl+C to stop.")
    if POWER:
        print("POWER MODE IS ON: Nova can run any command, but only after you")
        print("type your password each time. Every command is logged to: " + LOG_FILE)
    print("=" * 60)
    try:
        server = ThreadingHTTPServer((HOST, PORT), Handler)
    except OSError:
        print()
        print("!! Port %d is already in use." % PORT)
        print("!! Another Nova Helper is still running (maybe an old one without power mode).")
        print("!! Close EVERY helper window (or end 'Python' in Task Manager), then start this again.")
        input("Press Enter to close...")
        sys.exit(1)
    server.serve_forever()


if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        print("\nStopped.")
