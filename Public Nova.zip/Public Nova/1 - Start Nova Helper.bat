@echo off
cd /d "%~dp0"
title Nova Helper - keep this window open
python nova_helper.py --power
if errorlevel 1 py nova_helper.py --power
pause
